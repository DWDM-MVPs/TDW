var express = require('express');
var bodyParser = require('body-parser');
var cookiParser = require('cookie-parser');
var jwt = require('jsonwebtoken');
var mongoose = require('mongoose');
var app = express();
var url = "mongodb://localhost:27017/Users"
var port = 4000;

var db = mongoose.connect(url, {
    useNewUrlParser: true,
    useUnifiedTopology: true
}, () => {
    app.use(bodyParser.urlencoded({
        extended: true
    }));

    app.use(bodyParser.json());
    app.use(cookiParser());

    var User = require('./models/users.js');
    var tokemServerKey = 'AulasTDW20191219'


    app.post('/user', (req, res) => {
        var users = new Users(req.body);
        Users.save((err) => {
            if (err) {
                console.log('Errros to Save that user');
                res.status(500).send('Eternal Error');
            }
            return res.status(201).json(user);
        });
    });

    app.post('/login', (req, res) => {
        User.find({ 'name': req.body.name }, (err, users) => {
            if (err) {
                res.status(500).send('Eternal Error');
            } else if (users && users.length > 0) {
                if (users[0].password == req.body.password) {
                    var name = req.body.name
                    var token = jwt.sign({ name }, tokemServerKey, {
                        algorithm: 'HS256', expiresIn: 300

                    });
                    res.cookie('token', token, { maxAge: 300 * 1000 });
                    res.send('Login efectuado com sucesso');
                }
            } else {
                res.status(404).send('Not Found')
            }
        });
    });


    app.get('/identificar', (req, res) => {
        var token = req.cookies.token;
        console.log(req.body);
        if (!token) {
            res.status(401).send('Token undefined');
        } else {
            var payload;
            try {
                payload = jwt.verify(token, tokemServerKey);
            } catch (err) {
                res.status(401).send('Não Autorizado');
            }
            res.status(200).send('Olá' + payload.name + '!')
        }
    });







    app.listen(4000, function () {
        console.log('Sou o maior, uso a porta 4000');
    });
});



